// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XBAILEY_FFT_HW_H
#define XBAILEY_FFT_HW_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xbailey_fft_hw_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
    u16 DeviceId;
    u64 Control_BaseAddress;
} XBailey_fft_hw_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XBailey_fft_hw;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XBailey_fft_hw_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XBailey_fft_hw_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XBailey_fft_hw_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XBailey_fft_hw_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XBailey_fft_hw_Initialize(XBailey_fft_hw *InstancePtr, u16 DeviceId);
XBailey_fft_hw_Config* XBailey_fft_hw_LookupConfig(u16 DeviceId);
int XBailey_fft_hw_CfgInitialize(XBailey_fft_hw *InstancePtr, XBailey_fft_hw_Config *ConfigPtr);
#else
int XBailey_fft_hw_Initialize(XBailey_fft_hw *InstancePtr, const char* InstanceName);
int XBailey_fft_hw_Release(XBailey_fft_hw *InstancePtr);
#endif

void XBailey_fft_hw_Start(XBailey_fft_hw *InstancePtr);
u32 XBailey_fft_hw_IsDone(XBailey_fft_hw *InstancePtr);
u32 XBailey_fft_hw_IsIdle(XBailey_fft_hw *InstancePtr);
u32 XBailey_fft_hw_IsReady(XBailey_fft_hw *InstancePtr);
void XBailey_fft_hw_EnableAutoRestart(XBailey_fft_hw *InstancePtr);
void XBailey_fft_hw_DisableAutoRestart(XBailey_fft_hw *InstancePtr);

void XBailey_fft_hw_Set_In_real(XBailey_fft_hw *InstancePtr, u64 Data);
u64 XBailey_fft_hw_Get_In_real(XBailey_fft_hw *InstancePtr);
void XBailey_fft_hw_Set_In_imag(XBailey_fft_hw *InstancePtr, u64 Data);
u64 XBailey_fft_hw_Get_In_imag(XBailey_fft_hw *InstancePtr);
void XBailey_fft_hw_Set_log2_nfft(XBailey_fft_hw *InstancePtr, u32 Data);
u32 XBailey_fft_hw_Get_log2_nfft(XBailey_fft_hw *InstancePtr);
void XBailey_fft_hw_Set_Out_real(XBailey_fft_hw *InstancePtr, u64 Data);
u64 XBailey_fft_hw_Get_Out_real(XBailey_fft_hw *InstancePtr);
void XBailey_fft_hw_Set_Out_imag(XBailey_fft_hw *InstancePtr, u64 Data);
u64 XBailey_fft_hw_Get_Out_imag(XBailey_fft_hw *InstancePtr);

void XBailey_fft_hw_InterruptGlobalEnable(XBailey_fft_hw *InstancePtr);
void XBailey_fft_hw_InterruptGlobalDisable(XBailey_fft_hw *InstancePtr);
void XBailey_fft_hw_InterruptEnable(XBailey_fft_hw *InstancePtr, u32 Mask);
void XBailey_fft_hw_InterruptDisable(XBailey_fft_hw *InstancePtr, u32 Mask);
void XBailey_fft_hw_InterruptClear(XBailey_fft_hw *InstancePtr, u32 Mask);
u32 XBailey_fft_hw_InterruptGetEnabled(XBailey_fft_hw *InstancePtr);
u32 XBailey_fft_hw_InterruptGetStatus(XBailey_fft_hw *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
