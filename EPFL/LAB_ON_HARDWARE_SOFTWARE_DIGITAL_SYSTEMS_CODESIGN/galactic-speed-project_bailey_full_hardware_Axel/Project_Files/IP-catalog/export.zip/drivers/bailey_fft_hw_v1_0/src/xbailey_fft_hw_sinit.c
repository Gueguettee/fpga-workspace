// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xbailey_fft_hw.h"

extern XBailey_fft_hw_Config XBailey_fft_hw_ConfigTable[];

XBailey_fft_hw_Config *XBailey_fft_hw_LookupConfig(u16 DeviceId) {
	XBailey_fft_hw_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XBAILEY_FFT_HW_NUM_INSTANCES; Index++) {
		if (XBailey_fft_hw_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XBailey_fft_hw_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XBailey_fft_hw_Initialize(XBailey_fft_hw *InstancePtr, u16 DeviceId) {
	XBailey_fft_hw_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XBailey_fft_hw_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XBailey_fft_hw_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

