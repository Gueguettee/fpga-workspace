// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xbailey_fft_hw.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XBailey_fft_hw_CfgInitialize(XBailey_fft_hw *InstancePtr, XBailey_fft_hw_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XBailey_fft_hw_Start(XBailey_fft_hw *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBailey_fft_hw_ReadReg(InstancePtr->Control_BaseAddress, XBAILEY_FFT_HW_CONTROL_ADDR_AP_CTRL) & 0x80;
    XBailey_fft_hw_WriteReg(InstancePtr->Control_BaseAddress, XBAILEY_FFT_HW_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XBailey_fft_hw_IsDone(XBailey_fft_hw *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBailey_fft_hw_ReadReg(InstancePtr->Control_BaseAddress, XBAILEY_FFT_HW_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XBailey_fft_hw_IsIdle(XBailey_fft_hw *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBailey_fft_hw_ReadReg(InstancePtr->Control_BaseAddress, XBAILEY_FFT_HW_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XBailey_fft_hw_IsReady(XBailey_fft_hw *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBailey_fft_hw_ReadReg(InstancePtr->Control_BaseAddress, XBAILEY_FFT_HW_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XBailey_fft_hw_EnableAutoRestart(XBailey_fft_hw *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBailey_fft_hw_WriteReg(InstancePtr->Control_BaseAddress, XBAILEY_FFT_HW_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XBailey_fft_hw_DisableAutoRestart(XBailey_fft_hw *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBailey_fft_hw_WriteReg(InstancePtr->Control_BaseAddress, XBAILEY_FFT_HW_CONTROL_ADDR_AP_CTRL, 0);
}

void XBailey_fft_hw_Set_In_real(XBailey_fft_hw *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBailey_fft_hw_WriteReg(InstancePtr->Control_BaseAddress, XBAILEY_FFT_HW_CONTROL_ADDR_IN_REAL_DATA, (u32)(Data));
    XBailey_fft_hw_WriteReg(InstancePtr->Control_BaseAddress, XBAILEY_FFT_HW_CONTROL_ADDR_IN_REAL_DATA + 4, (u32)(Data >> 32));
}

u64 XBailey_fft_hw_Get_In_real(XBailey_fft_hw *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBailey_fft_hw_ReadReg(InstancePtr->Control_BaseAddress, XBAILEY_FFT_HW_CONTROL_ADDR_IN_REAL_DATA);
    Data += (u64)XBailey_fft_hw_ReadReg(InstancePtr->Control_BaseAddress, XBAILEY_FFT_HW_CONTROL_ADDR_IN_REAL_DATA + 4) << 32;
    return Data;
}

void XBailey_fft_hw_Set_In_imag(XBailey_fft_hw *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBailey_fft_hw_WriteReg(InstancePtr->Control_BaseAddress, XBAILEY_FFT_HW_CONTROL_ADDR_IN_IMAG_DATA, (u32)(Data));
    XBailey_fft_hw_WriteReg(InstancePtr->Control_BaseAddress, XBAILEY_FFT_HW_CONTROL_ADDR_IN_IMAG_DATA + 4, (u32)(Data >> 32));
}

u64 XBailey_fft_hw_Get_In_imag(XBailey_fft_hw *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBailey_fft_hw_ReadReg(InstancePtr->Control_BaseAddress, XBAILEY_FFT_HW_CONTROL_ADDR_IN_IMAG_DATA);
    Data += (u64)XBailey_fft_hw_ReadReg(InstancePtr->Control_BaseAddress, XBAILEY_FFT_HW_CONTROL_ADDR_IN_IMAG_DATA + 4) << 32;
    return Data;
}

void XBailey_fft_hw_Set_log2_nfft(XBailey_fft_hw *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBailey_fft_hw_WriteReg(InstancePtr->Control_BaseAddress, XBAILEY_FFT_HW_CONTROL_ADDR_LOG2_NFFT_DATA, Data);
}

u32 XBailey_fft_hw_Get_log2_nfft(XBailey_fft_hw *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBailey_fft_hw_ReadReg(InstancePtr->Control_BaseAddress, XBAILEY_FFT_HW_CONTROL_ADDR_LOG2_NFFT_DATA);
    return Data;
}

void XBailey_fft_hw_Set_Out_real(XBailey_fft_hw *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBailey_fft_hw_WriteReg(InstancePtr->Control_BaseAddress, XBAILEY_FFT_HW_CONTROL_ADDR_OUT_REAL_DATA, (u32)(Data));
    XBailey_fft_hw_WriteReg(InstancePtr->Control_BaseAddress, XBAILEY_FFT_HW_CONTROL_ADDR_OUT_REAL_DATA + 4, (u32)(Data >> 32));
}

u64 XBailey_fft_hw_Get_Out_real(XBailey_fft_hw *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBailey_fft_hw_ReadReg(InstancePtr->Control_BaseAddress, XBAILEY_FFT_HW_CONTROL_ADDR_OUT_REAL_DATA);
    Data += (u64)XBailey_fft_hw_ReadReg(InstancePtr->Control_BaseAddress, XBAILEY_FFT_HW_CONTROL_ADDR_OUT_REAL_DATA + 4) << 32;
    return Data;
}

void XBailey_fft_hw_Set_Out_imag(XBailey_fft_hw *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBailey_fft_hw_WriteReg(InstancePtr->Control_BaseAddress, XBAILEY_FFT_HW_CONTROL_ADDR_OUT_IMAG_DATA, (u32)(Data));
    XBailey_fft_hw_WriteReg(InstancePtr->Control_BaseAddress, XBAILEY_FFT_HW_CONTROL_ADDR_OUT_IMAG_DATA + 4, (u32)(Data >> 32));
}

u64 XBailey_fft_hw_Get_Out_imag(XBailey_fft_hw *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBailey_fft_hw_ReadReg(InstancePtr->Control_BaseAddress, XBAILEY_FFT_HW_CONTROL_ADDR_OUT_IMAG_DATA);
    Data += (u64)XBailey_fft_hw_ReadReg(InstancePtr->Control_BaseAddress, XBAILEY_FFT_HW_CONTROL_ADDR_OUT_IMAG_DATA + 4) << 32;
    return Data;
}

void XBailey_fft_hw_InterruptGlobalEnable(XBailey_fft_hw *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBailey_fft_hw_WriteReg(InstancePtr->Control_BaseAddress, XBAILEY_FFT_HW_CONTROL_ADDR_GIE, 1);
}

void XBailey_fft_hw_InterruptGlobalDisable(XBailey_fft_hw *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBailey_fft_hw_WriteReg(InstancePtr->Control_BaseAddress, XBAILEY_FFT_HW_CONTROL_ADDR_GIE, 0);
}

void XBailey_fft_hw_InterruptEnable(XBailey_fft_hw *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XBailey_fft_hw_ReadReg(InstancePtr->Control_BaseAddress, XBAILEY_FFT_HW_CONTROL_ADDR_IER);
    XBailey_fft_hw_WriteReg(InstancePtr->Control_BaseAddress, XBAILEY_FFT_HW_CONTROL_ADDR_IER, Register | Mask);
}

void XBailey_fft_hw_InterruptDisable(XBailey_fft_hw *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XBailey_fft_hw_ReadReg(InstancePtr->Control_BaseAddress, XBAILEY_FFT_HW_CONTROL_ADDR_IER);
    XBailey_fft_hw_WriteReg(InstancePtr->Control_BaseAddress, XBAILEY_FFT_HW_CONTROL_ADDR_IER, Register & (~Mask));
}

void XBailey_fft_hw_InterruptClear(XBailey_fft_hw *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBailey_fft_hw_WriteReg(InstancePtr->Control_BaseAddress, XBAILEY_FFT_HW_CONTROL_ADDR_ISR, Mask);
}

u32 XBailey_fft_hw_InterruptGetEnabled(XBailey_fft_hw *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XBailey_fft_hw_ReadReg(InstancePtr->Control_BaseAddress, XBAILEY_FFT_HW_CONTROL_ADDR_IER);
}

u32 XBailey_fft_hw_InterruptGetStatus(XBailey_fft_hw *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XBailey_fft_hw_ReadReg(InstancePtr->Control_BaseAddress, XBAILEY_FFT_HW_CONTROL_ADDR_ISR);
}

