// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
// control
// 0x00 : Control signals
//        bit 0  - ap_start (Read/Write/COH)
//        bit 1  - ap_done (Read/COR)
//        bit 2  - ap_idle (Read)
//        bit 3  - ap_ready (Read/COR)
//        bit 7  - auto_restart (Read/Write)
//        bit 9  - interrupt (Read)
//        others - reserved
// 0x04 : Global Interrupt Enable Register
//        bit 0  - Global Interrupt Enable (Read/Write)
//        others - reserved
// 0x08 : IP Interrupt Enable Register (Read/Write)
//        bit 0 - enable ap_done interrupt (Read/Write)
//        bit 1 - enable ap_ready interrupt (Read/Write)
//        others - reserved
// 0x0c : IP Interrupt Status Register (Read/TOW)
//        bit 0 - ap_done (Read/TOW)
//        bit 1 - ap_ready (Read/TOW)
//        others - reserved
// 0x10 : Data signal of In_real
//        bit 31~0 - In_real[31:0] (Read/Write)
// 0x14 : Data signal of In_real
//        bit 31~0 - In_real[63:32] (Read/Write)
// 0x18 : reserved
// 0x1c : Data signal of In_imag
//        bit 31~0 - In_imag[31:0] (Read/Write)
// 0x20 : Data signal of In_imag
//        bit 31~0 - In_imag[63:32] (Read/Write)
// 0x24 : reserved
// 0x28 : Data signal of log2_nfft
//        bit 31~0 - log2_nfft[31:0] (Read/Write)
// 0x2c : reserved
// 0x30 : Data signal of Out_real
//        bit 31~0 - Out_real[31:0] (Read/Write)
// 0x34 : Data signal of Out_real
//        bit 31~0 - Out_real[63:32] (Read/Write)
// 0x38 : reserved
// 0x3c : Data signal of Out_imag
//        bit 31~0 - Out_imag[31:0] (Read/Write)
// 0x40 : Data signal of Out_imag
//        bit 31~0 - Out_imag[63:32] (Read/Write)
// 0x44 : reserved
// 0x48 : Data signal of numHW
//        bit 31~0 - numHW[31:0] (Read/Write)
// 0x4c : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XFFT_HW_CONTROL_ADDR_AP_CTRL        0x00
#define XFFT_HW_CONTROL_ADDR_GIE            0x04
#define XFFT_HW_CONTROL_ADDR_IER            0x08
#define XFFT_HW_CONTROL_ADDR_ISR            0x0c
#define XFFT_HW_CONTROL_ADDR_IN_REAL_DATA   0x10
#define XFFT_HW_CONTROL_BITS_IN_REAL_DATA   64
#define XFFT_HW_CONTROL_ADDR_IN_IMAG_DATA   0x1c
#define XFFT_HW_CONTROL_BITS_IN_IMAG_DATA   64
#define XFFT_HW_CONTROL_ADDR_LOG2_NFFT_DATA 0x28
#define XFFT_HW_CONTROL_BITS_LOG2_NFFT_DATA 32
#define XFFT_HW_CONTROL_ADDR_OUT_REAL_DATA  0x30
#define XFFT_HW_CONTROL_BITS_OUT_REAL_DATA  64
#define XFFT_HW_CONTROL_ADDR_OUT_IMAG_DATA  0x3c
#define XFFT_HW_CONTROL_BITS_OUT_IMAG_DATA  64
#define XFFT_HW_CONTROL_ADDR_NUMHW_DATA     0x48
#define XFFT_HW_CONTROL_BITS_NUMHW_DATA     32

