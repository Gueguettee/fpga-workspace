// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XFFT_HW_H
#define XFFT_HW_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xfft_hw_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
    u16 DeviceId;
    u64 Control_BaseAddress;
} XFft_hw_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XFft_hw;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XFft_hw_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XFft_hw_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XFft_hw_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XFft_hw_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XFft_hw_Initialize(XFft_hw *InstancePtr, u16 DeviceId);
XFft_hw_Config* XFft_hw_LookupConfig(u16 DeviceId);
int XFft_hw_CfgInitialize(XFft_hw *InstancePtr, XFft_hw_Config *ConfigPtr);
#else
int XFft_hw_Initialize(XFft_hw *InstancePtr, const char* InstanceName);
int XFft_hw_Release(XFft_hw *InstancePtr);
#endif

void XFft_hw_Start(XFft_hw *InstancePtr);
u32 XFft_hw_IsDone(XFft_hw *InstancePtr);
u32 XFft_hw_IsIdle(XFft_hw *InstancePtr);
u32 XFft_hw_IsReady(XFft_hw *InstancePtr);
void XFft_hw_EnableAutoRestart(XFft_hw *InstancePtr);
void XFft_hw_DisableAutoRestart(XFft_hw *InstancePtr);

void XFft_hw_Set_In_real(XFft_hw *InstancePtr, u64 Data);
u64 XFft_hw_Get_In_real(XFft_hw *InstancePtr);
void XFft_hw_Set_In_imag(XFft_hw *InstancePtr, u64 Data);
u64 XFft_hw_Get_In_imag(XFft_hw *InstancePtr);
void XFft_hw_Set_log2_nfft(XFft_hw *InstancePtr, u32 Data);
u32 XFft_hw_Get_log2_nfft(XFft_hw *InstancePtr);
void XFft_hw_Set_Out_real(XFft_hw *InstancePtr, u64 Data);
u64 XFft_hw_Get_Out_real(XFft_hw *InstancePtr);
void XFft_hw_Set_Out_imag(XFft_hw *InstancePtr, u64 Data);
u64 XFft_hw_Get_Out_imag(XFft_hw *InstancePtr);

void XFft_hw_InterruptGlobalEnable(XFft_hw *InstancePtr);
void XFft_hw_InterruptGlobalDisable(XFft_hw *InstancePtr);
void XFft_hw_InterruptEnable(XFft_hw *InstancePtr, u32 Mask);
void XFft_hw_InterruptDisable(XFft_hw *InstancePtr, u32 Mask);
void XFft_hw_InterruptClear(XFft_hw *InstancePtr, u32 Mask);
u32 XFft_hw_InterruptGetEnabled(XFft_hw *InstancePtr);
u32 XFft_hw_InterruptGetStatus(XFft_hw *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
