// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xfft_hw.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XFft_hw_CfgInitialize(XFft_hw *InstancePtr, XFft_hw_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XFft_hw_Start(XFft_hw *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFft_hw_ReadReg(InstancePtr->Control_BaseAddress, XFFT_HW_CONTROL_ADDR_AP_CTRL) & 0x80;
    XFft_hw_WriteReg(InstancePtr->Control_BaseAddress, XFFT_HW_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XFft_hw_IsDone(XFft_hw *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFft_hw_ReadReg(InstancePtr->Control_BaseAddress, XFFT_HW_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XFft_hw_IsIdle(XFft_hw *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFft_hw_ReadReg(InstancePtr->Control_BaseAddress, XFFT_HW_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XFft_hw_IsReady(XFft_hw *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFft_hw_ReadReg(InstancePtr->Control_BaseAddress, XFFT_HW_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XFft_hw_EnableAutoRestart(XFft_hw *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFft_hw_WriteReg(InstancePtr->Control_BaseAddress, XFFT_HW_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XFft_hw_DisableAutoRestart(XFft_hw *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFft_hw_WriteReg(InstancePtr->Control_BaseAddress, XFFT_HW_CONTROL_ADDR_AP_CTRL, 0);
}

void XFft_hw_Set_In_real(XFft_hw *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFft_hw_WriteReg(InstancePtr->Control_BaseAddress, XFFT_HW_CONTROL_ADDR_IN_REAL_DATA, (u32)(Data));
    XFft_hw_WriteReg(InstancePtr->Control_BaseAddress, XFFT_HW_CONTROL_ADDR_IN_REAL_DATA + 4, (u32)(Data >> 32));
}

u64 XFft_hw_Get_In_real(XFft_hw *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFft_hw_ReadReg(InstancePtr->Control_BaseAddress, XFFT_HW_CONTROL_ADDR_IN_REAL_DATA);
    Data += (u64)XFft_hw_ReadReg(InstancePtr->Control_BaseAddress, XFFT_HW_CONTROL_ADDR_IN_REAL_DATA + 4) << 32;
    return Data;
}

void XFft_hw_Set_In_imag(XFft_hw *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFft_hw_WriteReg(InstancePtr->Control_BaseAddress, XFFT_HW_CONTROL_ADDR_IN_IMAG_DATA, (u32)(Data));
    XFft_hw_WriteReg(InstancePtr->Control_BaseAddress, XFFT_HW_CONTROL_ADDR_IN_IMAG_DATA + 4, (u32)(Data >> 32));
}

u64 XFft_hw_Get_In_imag(XFft_hw *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFft_hw_ReadReg(InstancePtr->Control_BaseAddress, XFFT_HW_CONTROL_ADDR_IN_IMAG_DATA);
    Data += (u64)XFft_hw_ReadReg(InstancePtr->Control_BaseAddress, XFFT_HW_CONTROL_ADDR_IN_IMAG_DATA + 4) << 32;
    return Data;
}

void XFft_hw_Set_log2_nfft(XFft_hw *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFft_hw_WriteReg(InstancePtr->Control_BaseAddress, XFFT_HW_CONTROL_ADDR_LOG2_NFFT_DATA, Data);
}

u32 XFft_hw_Get_log2_nfft(XFft_hw *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFft_hw_ReadReg(InstancePtr->Control_BaseAddress, XFFT_HW_CONTROL_ADDR_LOG2_NFFT_DATA);
    return Data;
}

void XFft_hw_Set_Out_real(XFft_hw *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFft_hw_WriteReg(InstancePtr->Control_BaseAddress, XFFT_HW_CONTROL_ADDR_OUT_REAL_DATA, (u32)(Data));
    XFft_hw_WriteReg(InstancePtr->Control_BaseAddress, XFFT_HW_CONTROL_ADDR_OUT_REAL_DATA + 4, (u32)(Data >> 32));
}

u64 XFft_hw_Get_Out_real(XFft_hw *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFft_hw_ReadReg(InstancePtr->Control_BaseAddress, XFFT_HW_CONTROL_ADDR_OUT_REAL_DATA);
    Data += (u64)XFft_hw_ReadReg(InstancePtr->Control_BaseAddress, XFFT_HW_CONTROL_ADDR_OUT_REAL_DATA + 4) << 32;
    return Data;
}

void XFft_hw_Set_Out_imag(XFft_hw *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFft_hw_WriteReg(InstancePtr->Control_BaseAddress, XFFT_HW_CONTROL_ADDR_OUT_IMAG_DATA, (u32)(Data));
    XFft_hw_WriteReg(InstancePtr->Control_BaseAddress, XFFT_HW_CONTROL_ADDR_OUT_IMAG_DATA + 4, (u32)(Data >> 32));
}

u64 XFft_hw_Get_Out_imag(XFft_hw *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFft_hw_ReadReg(InstancePtr->Control_BaseAddress, XFFT_HW_CONTROL_ADDR_OUT_IMAG_DATA);
    Data += (u64)XFft_hw_ReadReg(InstancePtr->Control_BaseAddress, XFFT_HW_CONTROL_ADDR_OUT_IMAG_DATA + 4) << 32;
    return Data;
}

void XFft_hw_InterruptGlobalEnable(XFft_hw *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFft_hw_WriteReg(InstancePtr->Control_BaseAddress, XFFT_HW_CONTROL_ADDR_GIE, 1);
}

void XFft_hw_InterruptGlobalDisable(XFft_hw *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFft_hw_WriteReg(InstancePtr->Control_BaseAddress, XFFT_HW_CONTROL_ADDR_GIE, 0);
}

void XFft_hw_InterruptEnable(XFft_hw *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XFft_hw_ReadReg(InstancePtr->Control_BaseAddress, XFFT_HW_CONTROL_ADDR_IER);
    XFft_hw_WriteReg(InstancePtr->Control_BaseAddress, XFFT_HW_CONTROL_ADDR_IER, Register | Mask);
}

void XFft_hw_InterruptDisable(XFft_hw *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XFft_hw_ReadReg(InstancePtr->Control_BaseAddress, XFFT_HW_CONTROL_ADDR_IER);
    XFft_hw_WriteReg(InstancePtr->Control_BaseAddress, XFFT_HW_CONTROL_ADDR_IER, Register & (~Mask));
}

void XFft_hw_InterruptClear(XFft_hw *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFft_hw_WriteReg(InstancePtr->Control_BaseAddress, XFFT_HW_CONTROL_ADDR_ISR, Mask);
}

u32 XFft_hw_InterruptGetEnabled(XFft_hw *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XFft_hw_ReadReg(InstancePtr->Control_BaseAddress, XFFT_HW_CONTROL_ADDR_IER);
}

u32 XFft_hw_InterruptGetStatus(XFft_hw *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XFft_hw_ReadReg(InstancePtr->Control_BaseAddress, XFFT_HW_CONTROL_ADDR_ISR);
}

