// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xfft_hw.h"

extern XFft_hw_Config XFft_hw_ConfigTable[];

XFft_hw_Config *XFft_hw_LookupConfig(u16 DeviceId) {
	XFft_hw_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XFFT_HW_NUM_INSTANCES; Index++) {
		if (XFft_hw_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XFft_hw_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XFft_hw_Initialize(XFft_hw *InstancePtr, u16 DeviceId) {
	XFft_hw_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XFft_hw_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XFft_hw_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

