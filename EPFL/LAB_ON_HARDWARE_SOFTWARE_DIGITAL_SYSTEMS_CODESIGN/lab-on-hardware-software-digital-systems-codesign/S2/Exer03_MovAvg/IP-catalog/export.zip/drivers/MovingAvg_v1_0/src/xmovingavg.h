// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XMOVINGAVG_H
#define XMOVINGAVG_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xmovingavg_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
    u16 DeviceId;
    u64 Control_BaseAddress;
} XMovingavg_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XMovingavg;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XMovingavg_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XMovingavg_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XMovingavg_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XMovingavg_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XMovingavg_Initialize(XMovingavg *InstancePtr, u16 DeviceId);
XMovingavg_Config* XMovingavg_LookupConfig(u16 DeviceId);
int XMovingavg_CfgInitialize(XMovingavg *InstancePtr, XMovingavg_Config *ConfigPtr);
#else
int XMovingavg_Initialize(XMovingavg *InstancePtr, const char* InstanceName);
int XMovingavg_Release(XMovingavg *InstancePtr);
#endif

void XMovingavg_Start(XMovingavg *InstancePtr);
u32 XMovingavg_IsDone(XMovingavg *InstancePtr);
u32 XMovingavg_IsIdle(XMovingavg *InstancePtr);
u32 XMovingavg_IsReady(XMovingavg *InstancePtr);
void XMovingavg_EnableAutoRestart(XMovingavg *InstancePtr);
void XMovingavg_DisableAutoRestart(XMovingavg *InstancePtr);

void XMovingavg_Set_input_r(XMovingavg *InstancePtr, u64 Data);
u64 XMovingavg_Get_input_r(XMovingavg *InstancePtr);
void XMovingavg_Set_output_r(XMovingavg *InstancePtr, u64 Data);
u64 XMovingavg_Get_output_r(XMovingavg *InstancePtr);
void XMovingavg_Set_length_r(XMovingavg *InstancePtr, u32 Data);
u32 XMovingavg_Get_length_r(XMovingavg *InstancePtr);

void XMovingavg_InterruptGlobalEnable(XMovingavg *InstancePtr);
void XMovingavg_InterruptGlobalDisable(XMovingavg *InstancePtr);
void XMovingavg_InterruptEnable(XMovingavg *InstancePtr, u32 Mask);
void XMovingavg_InterruptDisable(XMovingavg *InstancePtr, u32 Mask);
void XMovingavg_InterruptClear(XMovingavg *InstancePtr, u32 Mask);
u32 XMovingavg_InterruptGetEnabled(XMovingavg *InstancePtr);
u32 XMovingavg_InterruptGetStatus(XMovingavg *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
