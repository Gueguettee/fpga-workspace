// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xmovingavg.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XMovingavg_CfgInitialize(XMovingavg *InstancePtr, XMovingavg_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XMovingavg_Start(XMovingavg *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMovingavg_ReadReg(InstancePtr->Control_BaseAddress, XMOVINGAVG_CONTROL_ADDR_AP_CTRL) & 0x80;
    XMovingavg_WriteReg(InstancePtr->Control_BaseAddress, XMOVINGAVG_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XMovingavg_IsDone(XMovingavg *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMovingavg_ReadReg(InstancePtr->Control_BaseAddress, XMOVINGAVG_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XMovingavg_IsIdle(XMovingavg *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMovingavg_ReadReg(InstancePtr->Control_BaseAddress, XMOVINGAVG_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XMovingavg_IsReady(XMovingavg *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMovingavg_ReadReg(InstancePtr->Control_BaseAddress, XMOVINGAVG_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XMovingavg_EnableAutoRestart(XMovingavg *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMovingavg_WriteReg(InstancePtr->Control_BaseAddress, XMOVINGAVG_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XMovingavg_DisableAutoRestart(XMovingavg *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMovingavg_WriteReg(InstancePtr->Control_BaseAddress, XMOVINGAVG_CONTROL_ADDR_AP_CTRL, 0);
}

void XMovingavg_Set_input_r(XMovingavg *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMovingavg_WriteReg(InstancePtr->Control_BaseAddress, XMOVINGAVG_CONTROL_ADDR_INPUT_R_DATA, (u32)(Data));
    XMovingavg_WriteReg(InstancePtr->Control_BaseAddress, XMOVINGAVG_CONTROL_ADDR_INPUT_R_DATA + 4, (u32)(Data >> 32));
}

u64 XMovingavg_Get_input_r(XMovingavg *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMovingavg_ReadReg(InstancePtr->Control_BaseAddress, XMOVINGAVG_CONTROL_ADDR_INPUT_R_DATA);
    Data += (u64)XMovingavg_ReadReg(InstancePtr->Control_BaseAddress, XMOVINGAVG_CONTROL_ADDR_INPUT_R_DATA + 4) << 32;
    return Data;
}

void XMovingavg_Set_output_r(XMovingavg *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMovingavg_WriteReg(InstancePtr->Control_BaseAddress, XMOVINGAVG_CONTROL_ADDR_OUTPUT_R_DATA, (u32)(Data));
    XMovingavg_WriteReg(InstancePtr->Control_BaseAddress, XMOVINGAVG_CONTROL_ADDR_OUTPUT_R_DATA + 4, (u32)(Data >> 32));
}

u64 XMovingavg_Get_output_r(XMovingavg *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMovingavg_ReadReg(InstancePtr->Control_BaseAddress, XMOVINGAVG_CONTROL_ADDR_OUTPUT_R_DATA);
    Data += (u64)XMovingavg_ReadReg(InstancePtr->Control_BaseAddress, XMOVINGAVG_CONTROL_ADDR_OUTPUT_R_DATA + 4) << 32;
    return Data;
}

void XMovingavg_Set_length_r(XMovingavg *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMovingavg_WriteReg(InstancePtr->Control_BaseAddress, XMOVINGAVG_CONTROL_ADDR_LENGTH_R_DATA, Data);
}

u32 XMovingavg_Get_length_r(XMovingavg *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMovingavg_ReadReg(InstancePtr->Control_BaseAddress, XMOVINGAVG_CONTROL_ADDR_LENGTH_R_DATA);
    return Data;
}

void XMovingavg_InterruptGlobalEnable(XMovingavg *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMovingavg_WriteReg(InstancePtr->Control_BaseAddress, XMOVINGAVG_CONTROL_ADDR_GIE, 1);
}

void XMovingavg_InterruptGlobalDisable(XMovingavg *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMovingavg_WriteReg(InstancePtr->Control_BaseAddress, XMOVINGAVG_CONTROL_ADDR_GIE, 0);
}

void XMovingavg_InterruptEnable(XMovingavg *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XMovingavg_ReadReg(InstancePtr->Control_BaseAddress, XMOVINGAVG_CONTROL_ADDR_IER);
    XMovingavg_WriteReg(InstancePtr->Control_BaseAddress, XMOVINGAVG_CONTROL_ADDR_IER, Register | Mask);
}

void XMovingavg_InterruptDisable(XMovingavg *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XMovingavg_ReadReg(InstancePtr->Control_BaseAddress, XMOVINGAVG_CONTROL_ADDR_IER);
    XMovingavg_WriteReg(InstancePtr->Control_BaseAddress, XMOVINGAVG_CONTROL_ADDR_IER, Register & (~Mask));
}

void XMovingavg_InterruptClear(XMovingavg *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMovingavg_WriteReg(InstancePtr->Control_BaseAddress, XMOVINGAVG_CONTROL_ADDR_ISR, Mask);
}

u32 XMovingavg_InterruptGetEnabled(XMovingavg *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMovingavg_ReadReg(InstancePtr->Control_BaseAddress, XMOVINGAVG_CONTROL_ADDR_IER);
}

u32 XMovingavg_InterruptGetStatus(XMovingavg *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMovingavg_ReadReg(InstancePtr->Control_BaseAddress, XMOVINGAVG_CONTROL_ADDR_ISR);
}

