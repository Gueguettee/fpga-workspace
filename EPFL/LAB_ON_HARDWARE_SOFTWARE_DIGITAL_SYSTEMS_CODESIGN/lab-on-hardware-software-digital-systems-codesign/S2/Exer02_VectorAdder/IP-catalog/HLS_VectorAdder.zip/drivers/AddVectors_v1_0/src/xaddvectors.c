// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xaddvectors.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XAddvectors_CfgInitialize(XAddvectors *InstancePtr, XAddvectors_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XAddvectors_Start(XAddvectors *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAddvectors_ReadReg(InstancePtr->Control_BaseAddress, XADDVECTORS_CONTROL_ADDR_AP_CTRL) & 0x80;
    XAddvectors_WriteReg(InstancePtr->Control_BaseAddress, XADDVECTORS_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XAddvectors_IsDone(XAddvectors *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAddvectors_ReadReg(InstancePtr->Control_BaseAddress, XADDVECTORS_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XAddvectors_IsIdle(XAddvectors *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAddvectors_ReadReg(InstancePtr->Control_BaseAddress, XADDVECTORS_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XAddvectors_IsReady(XAddvectors *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAddvectors_ReadReg(InstancePtr->Control_BaseAddress, XADDVECTORS_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XAddvectors_EnableAutoRestart(XAddvectors *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAddvectors_WriteReg(InstancePtr->Control_BaseAddress, XADDVECTORS_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XAddvectors_DisableAutoRestart(XAddvectors *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAddvectors_WriteReg(InstancePtr->Control_BaseAddress, XADDVECTORS_CONTROL_ADDR_AP_CTRL, 0);
}

void XAddvectors_Set_input1(XAddvectors *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAddvectors_WriteReg(InstancePtr->Control_BaseAddress, XADDVECTORS_CONTROL_ADDR_INPUT1_DATA, (u32)(Data));
    XAddvectors_WriteReg(InstancePtr->Control_BaseAddress, XADDVECTORS_CONTROL_ADDR_INPUT1_DATA + 4, (u32)(Data >> 32));
}

u64 XAddvectors_Get_input1(XAddvectors *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAddvectors_ReadReg(InstancePtr->Control_BaseAddress, XADDVECTORS_CONTROL_ADDR_INPUT1_DATA);
    Data += (u64)XAddvectors_ReadReg(InstancePtr->Control_BaseAddress, XADDVECTORS_CONTROL_ADDR_INPUT1_DATA + 4) << 32;
    return Data;
}

void XAddvectors_Set_input2(XAddvectors *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAddvectors_WriteReg(InstancePtr->Control_BaseAddress, XADDVECTORS_CONTROL_ADDR_INPUT2_DATA, (u32)(Data));
    XAddvectors_WriteReg(InstancePtr->Control_BaseAddress, XADDVECTORS_CONTROL_ADDR_INPUT2_DATA + 4, (u32)(Data >> 32));
}

u64 XAddvectors_Get_input2(XAddvectors *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAddvectors_ReadReg(InstancePtr->Control_BaseAddress, XADDVECTORS_CONTROL_ADDR_INPUT2_DATA);
    Data += (u64)XAddvectors_ReadReg(InstancePtr->Control_BaseAddress, XADDVECTORS_CONTROL_ADDR_INPUT2_DATA + 4) << 32;
    return Data;
}

void XAddvectors_Set_output_r(XAddvectors *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAddvectors_WriteReg(InstancePtr->Control_BaseAddress, XADDVECTORS_CONTROL_ADDR_OUTPUT_R_DATA, (u32)(Data));
    XAddvectors_WriteReg(InstancePtr->Control_BaseAddress, XADDVECTORS_CONTROL_ADDR_OUTPUT_R_DATA + 4, (u32)(Data >> 32));
}

u64 XAddvectors_Get_output_r(XAddvectors *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAddvectors_ReadReg(InstancePtr->Control_BaseAddress, XADDVECTORS_CONTROL_ADDR_OUTPUT_R_DATA);
    Data += (u64)XAddvectors_ReadReg(InstancePtr->Control_BaseAddress, XADDVECTORS_CONTROL_ADDR_OUTPUT_R_DATA + 4) << 32;
    return Data;
}

void XAddvectors_Set_length_r(XAddvectors *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAddvectors_WriteReg(InstancePtr->Control_BaseAddress, XADDVECTORS_CONTROL_ADDR_LENGTH_R_DATA, Data);
}

u32 XAddvectors_Get_length_r(XAddvectors *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAddvectors_ReadReg(InstancePtr->Control_BaseAddress, XADDVECTORS_CONTROL_ADDR_LENGTH_R_DATA);
    return Data;
}

void XAddvectors_Set_accum(XAddvectors *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAddvectors_WriteReg(InstancePtr->Control_BaseAddress, XADDVECTORS_CONTROL_ADDR_ACCUM_DATA, Data);
}

u32 XAddvectors_Get_accum(XAddvectors *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAddvectors_ReadReg(InstancePtr->Control_BaseAddress, XADDVECTORS_CONTROL_ADDR_ACCUM_DATA);
    return Data;
}

void XAddvectors_InterruptGlobalEnable(XAddvectors *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAddvectors_WriteReg(InstancePtr->Control_BaseAddress, XADDVECTORS_CONTROL_ADDR_GIE, 1);
}

void XAddvectors_InterruptGlobalDisable(XAddvectors *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAddvectors_WriteReg(InstancePtr->Control_BaseAddress, XADDVECTORS_CONTROL_ADDR_GIE, 0);
}

void XAddvectors_InterruptEnable(XAddvectors *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XAddvectors_ReadReg(InstancePtr->Control_BaseAddress, XADDVECTORS_CONTROL_ADDR_IER);
    XAddvectors_WriteReg(InstancePtr->Control_BaseAddress, XADDVECTORS_CONTROL_ADDR_IER, Register | Mask);
}

void XAddvectors_InterruptDisable(XAddvectors *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XAddvectors_ReadReg(InstancePtr->Control_BaseAddress, XADDVECTORS_CONTROL_ADDR_IER);
    XAddvectors_WriteReg(InstancePtr->Control_BaseAddress, XADDVECTORS_CONTROL_ADDR_IER, Register & (~Mask));
}

void XAddvectors_InterruptClear(XAddvectors *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAddvectors_WriteReg(InstancePtr->Control_BaseAddress, XADDVECTORS_CONTROL_ADDR_ISR, Mask);
}

u32 XAddvectors_InterruptGetEnabled(XAddvectors *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XAddvectors_ReadReg(InstancePtr->Control_BaseAddress, XADDVECTORS_CONTROL_ADDR_IER);
}

u32 XAddvectors_InterruptGetStatus(XAddvectors *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XAddvectors_ReadReg(InstancePtr->Control_BaseAddress, XADDVECTORS_CONTROL_ADDR_ISR);
}

