// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XADDVECTORS_H
#define XADDVECTORS_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xaddvectors_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
    u16 DeviceId;
    u64 Control_BaseAddress;
} XAddvectors_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XAddvectors;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XAddvectors_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XAddvectors_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XAddvectors_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XAddvectors_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XAddvectors_Initialize(XAddvectors *InstancePtr, u16 DeviceId);
XAddvectors_Config* XAddvectors_LookupConfig(u16 DeviceId);
int XAddvectors_CfgInitialize(XAddvectors *InstancePtr, XAddvectors_Config *ConfigPtr);
#else
int XAddvectors_Initialize(XAddvectors *InstancePtr, const char* InstanceName);
int XAddvectors_Release(XAddvectors *InstancePtr);
#endif

void XAddvectors_Start(XAddvectors *InstancePtr);
u32 XAddvectors_IsDone(XAddvectors *InstancePtr);
u32 XAddvectors_IsIdle(XAddvectors *InstancePtr);
u32 XAddvectors_IsReady(XAddvectors *InstancePtr);
void XAddvectors_EnableAutoRestart(XAddvectors *InstancePtr);
void XAddvectors_DisableAutoRestart(XAddvectors *InstancePtr);

void XAddvectors_Set_input1(XAddvectors *InstancePtr, u64 Data);
u64 XAddvectors_Get_input1(XAddvectors *InstancePtr);
void XAddvectors_Set_input2(XAddvectors *InstancePtr, u64 Data);
u64 XAddvectors_Get_input2(XAddvectors *InstancePtr);
void XAddvectors_Set_output_r(XAddvectors *InstancePtr, u64 Data);
u64 XAddvectors_Get_output_r(XAddvectors *InstancePtr);
void XAddvectors_Set_length_r(XAddvectors *InstancePtr, u32 Data);
u32 XAddvectors_Get_length_r(XAddvectors *InstancePtr);
void XAddvectors_Set_accum(XAddvectors *InstancePtr, u32 Data);
u32 XAddvectors_Get_accum(XAddvectors *InstancePtr);

void XAddvectors_InterruptGlobalEnable(XAddvectors *InstancePtr);
void XAddvectors_InterruptGlobalDisable(XAddvectors *InstancePtr);
void XAddvectors_InterruptEnable(XAddvectors *InstancePtr, u32 Mask);
void XAddvectors_InterruptDisable(XAddvectors *InstancePtr, u32 Mask);
void XAddvectors_InterruptClear(XAddvectors *InstancePtr, u32 Mask);
u32 XAddvectors_InterruptGetEnabled(XAddvectors *InstancePtr);
u32 XAddvectors_InterruptGetStatus(XAddvectors *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
