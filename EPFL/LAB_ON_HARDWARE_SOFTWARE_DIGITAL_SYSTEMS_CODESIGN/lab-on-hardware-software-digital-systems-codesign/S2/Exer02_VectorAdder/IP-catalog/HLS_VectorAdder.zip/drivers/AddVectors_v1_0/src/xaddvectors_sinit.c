// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xaddvectors.h"

extern XAddvectors_Config XAddvectors_ConfigTable[];

XAddvectors_Config *XAddvectors_LookupConfig(u16 DeviceId) {
	XAddvectors_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XADDVECTORS_NUM_INSTANCES; Index++) {
		if (XAddvectors_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XAddvectors_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XAddvectors_Initialize(XAddvectors *InstancePtr, u16 DeviceId) {
	XAddvectors_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XAddvectors_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XAddvectors_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

